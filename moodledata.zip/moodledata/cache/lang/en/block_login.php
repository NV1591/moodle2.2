<?php $this->cache['en']['block_login'] = array (
  'pluginname' => 'Login',
);