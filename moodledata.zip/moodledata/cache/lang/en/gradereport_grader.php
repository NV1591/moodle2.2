<?php $this->cache['en']['gradereport_grader'] = array (
  'ajaxclicktoclose' => 'Click this box to remove it',
  'ajaxerror' => 'Error',
  'ajaxfailedupdate' => 'Unable to update [1] for [2]',
  'ajaxfieldchanged' => 'The field you are currently editing has changed, would you like to use the updated value?',
  'ajaxchoosescale' => 'Choose',
  'grader:manage' => 'Manage the grader report',
  'grader:view' => 'View the grader report',
  'pluginname' => 'Grader report',
  'preferences' => 'Grader report preferences',
);