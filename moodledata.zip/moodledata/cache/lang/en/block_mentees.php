<?php $this->cache['en']['block_mentees'] = array (
  'configtitle' => 'Block title',
  'configtitleblankhides' => 'Block title (no title if blank)',
  'leaveblanktohide' => 'leave blank to hide the title',
  'newmenteesblock' => '(new Mentees block)',
  'pluginname' => 'Mentees',
);