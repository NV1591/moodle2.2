<?php $this->cache['en']['repository_user'] = array (
  'configplugin' => 'Configuration for user private files repository',
  'pluginname_help' => 'Files in user private area',
  'pluginname' => 'Private files',
  'emptyfilelist' => 'There are no files to show',
  'user:view' => 'View user private files',
);