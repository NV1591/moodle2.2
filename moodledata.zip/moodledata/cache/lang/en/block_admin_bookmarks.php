<?php $this->cache['en']['block_admin_bookmarks'] = array (
  'pluginname' => 'Admin bookmarks',
);