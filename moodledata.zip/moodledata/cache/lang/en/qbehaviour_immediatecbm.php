<?php $this->cache['en']['qbehaviour_immediatecbm'] = array (
  'pleaseselectacertainty' => 'Please select a certainty.',
  'pluginname' => 'Immediate feedback with CBM',
);