<?php $this->cache['en']['workshopform_rubric'] = array (
  'addmoredimensions' => 'Blanks for {$a} more criteria',
  'configuration' => 'Rubric configuration',
  'criteria' => 'Criteria',
  'dimensiondescription' => 'Description',
  'dimensionnumber' => 'Criterion {$a}',
  'layout' => 'Rubric layout',
  'layoutgrid' => 'Grid',
  'layoutlist' => 'List',
  'levelgroup' => 'Level grade and definition',
  'levels' => 'Levels',
  'mustchooseone' => 'You have to select one of these items',
  'pluginname' => 'Rubric',
);