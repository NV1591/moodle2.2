<?php $this->cache['en']['format_social'] = array (
  'sectionname' => 'section',
  'pluginname' => 'Social format',
);