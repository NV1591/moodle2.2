<?php $this->cache['en']['mod_folder'] = array (
  'contentheader' => 'Content',
  'folder:managefiles' => 'Manage files in folder module',
  'folder:view' => 'View folder content',
  'foldercontent' => 'Files and subfolders',
  'modulename' => 'Folder',
  'modulenameplural' => 'Folders',
  'neverseen' => 'Never seen',
  'page-mod-folder-x' => 'Any folder module page',
  'page-mod-folder-view' => 'Folder module main page',
  'pluginadministration' => 'Folder administration',
  'pluginname' => 'Folder',
);