<?php $this->cache['en']['tool_timezoneimport'] = array (
  'configintrotimezones' => 'This page will search for new information about world timezones (including daylight savings time rules) and update your local database with this information.  These locations will be checked, in order: {$a} Do you wish to update your timezones now?',
  'importtimezones' => 'Update complete list of timezones',
  'importtimezonescount' => '{$a->count} entries imported from {$a->source}',
  'importtimezonesfailed' => 'No sources found! (Bad news)',
  'pluginname' => 'Timezones updater',
  'updatetimezones' => 'Update timezones',
);