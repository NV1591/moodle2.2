<?php $this->cache['en']['report_loglive'] = array (
  'loglive:view' => 'View live logs',
  'pluginname' => 'Live logs',
  'livelogs' => 'Live logs from the past hour',
);