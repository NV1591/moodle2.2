<?php $this->cache['en']['block_site_main_menu'] = array (
  'pluginname' => 'Main menu',
);