<?php $this->cache['en']['enrol_meta'] = array (
  'linkedcourse' => 'Link course',
  'meta:config' => 'Configure meta enrol instances',
  'meta:selectaslinked' => 'Select course as meta linked',
  'meta:unenrol' => 'Unenrol suspended users',
  'nosyncroleids' => 'Roles that are not synchronised',
  'nosyncroleids_desc' => 'By default all course level role assignments are synchronised from parent to child courses. Roles that are selected here will not be included in the synchronisation process. The roles available for synchronisation will be updated in the next cron execution.',
  'pluginname' => 'Course meta link',
  'pluginname_desc' => 'Course meta link enrolment plugin synchronises enrolments and roles in two different courses.',
  'syncall' => 'Synchronise all enrolled users',
  'syncall_desc' => 'If enabled all enrolled users are synchronised even if they have no role in parent course, if disabled only users that have at least one synchronised role are enrolled in child course.',
);