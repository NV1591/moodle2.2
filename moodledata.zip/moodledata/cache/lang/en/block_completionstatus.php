<?php $this->cache['en']['block_completionstatus'] = array (
  'completionprogressdetails' => 'Completion progress details',
  'completionstatus' => 'Course completion status',
  'criteriagroup' => 'Criteria group',
  'firstofsecond' => '{$a->first} of {$a->second}',
  'pluginname' => 'Course completion status',
  'requirement' => 'Requirement',
  'returntocourse' => 'Return to course',
);