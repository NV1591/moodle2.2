<?php $this->cache['en']['block_messages'] = array (
  'pluginname' => 'Messages',
);