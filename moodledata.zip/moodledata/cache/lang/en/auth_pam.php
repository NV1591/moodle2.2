<?php $this->cache['en']['auth_pam'] = array (
  'auth_pamdescription' => 'This method uses PAM to access the native usernames on this server. You have to install <a href="http://www.math.ohio-state.edu/~ccunning/pam_auth/">PHP4 PAM Authentication</a> in order to use this module.',
  'auth_passwordisexpired' => 'Your password is expired. Do you want change your password now?',
  'auth_passwordwillexpire' => 'Your password will expire in {$a} days. Do you want change your password now?',
  'pluginname' => 'PAM (Pluggable Authentication Modules)',
);