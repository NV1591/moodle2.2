<?php $this->cache['en']['qbehaviour_deferredcbm'] = array (
  'assumingcertainty' => 'You did not select a certainty. Assuming: {$a}.',
  'certainty1' => 'Not very (less than 67%)',
  'certainty2' => 'Fairly (more than 67%)',
  'certainty3' => 'Very (more than 80%)',
  'howcertainareyou' => 'How certain are you? {$a}',
  'markadjustment' => 'Based on the certainty you expressed, your base mark of {$a->rawmark} was adjusted to {$a->mark}.',
  'pluginname' => 'Deferred feedback with CBM',
);