<?php $this->cache['en']['block_mnet_hosts'] = array (
  'error_authmnetneeded' => 'MNet authentication plugin must be enabled to see the list of MNet network servers',
  'error_localusersonly' => 'Remote users can not jump to other MNet network servers from this host',
  'error_roamcapabilityneeded' => 'Users need the capability \'Roam to a remote application via MNet\' to see the list of MNet network servers',
  'pluginname' => 'Network servers',
  'server' => 'Server',
);