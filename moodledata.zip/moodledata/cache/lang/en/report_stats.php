<?php $this->cache['en']['report_stats'] = array (
  'pluginname' => 'Statistics',
  'page-report-stats-x' => 'Any statistics report',
  'page-report-stats-index' => 'Course statistics report',
  'page-report-stats-user' => 'User course statistics report',
  'stats:view' => 'View course statistics report',
);