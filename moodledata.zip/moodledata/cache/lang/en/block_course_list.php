<?php $this->cache['en']['block_course_list'] = array (
  'adminview' => 'Admin view',
  'allcourses' => 'Admin user sees all courses',
  'configadminview' => 'What should the admin see in the course list block?',
  'confighideallcourseslink' => 'Hide "All courses" link at the bottom of the block. Link hiding does not affects Admin\'s view',
  'hideallcourseslink' => 'Hide All courses link',
  'owncourses' => 'Admin user sees own courses',
  'pluginname' => 'Course list',
);