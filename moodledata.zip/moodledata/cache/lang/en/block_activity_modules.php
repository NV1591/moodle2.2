<?php $this->cache['en']['block_activity_modules'] = array (
  'pluginname' => 'Activities',
);