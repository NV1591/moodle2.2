<?php $this->cache['en']['report_configlog'] = array (
  'configlog' => 'Config changes',
  'oldvalue' => 'Original value',
  'plugin' => 'Plugin',
  'pluginname' => 'Config changes',
  'setting' => 'Setting',
  'timemodified' => 'Date',
  'value' => 'New value',
);