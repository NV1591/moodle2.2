<?php $this->cache['en']['qbehaviour_manualgraded'] = array (
  'pluginname' => 'Manually graded',
);