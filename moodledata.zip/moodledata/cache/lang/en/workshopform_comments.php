<?php $this->cache['en']['workshopform_comments'] = array (
  'addmoredimensions' => 'Blanks for {$a} more aspects',
  'dimensioncomment' => 'Comment',
  'dimensiondescription' => 'Description',
  'dimensionnumber' => 'Aspect {$a}',
  'pluginname' => 'Comments',
);