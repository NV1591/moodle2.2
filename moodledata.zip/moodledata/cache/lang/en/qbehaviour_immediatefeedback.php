<?php $this->cache['en']['qbehaviour_immediatefeedback'] = array (
  'notcomplete' => 'Not complete',
  'pluginname' => 'Immediate feedback',
);