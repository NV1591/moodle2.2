<?php $this->cache['en']['report_backups'] = array (
  'pluginname' => 'Backups report',
);