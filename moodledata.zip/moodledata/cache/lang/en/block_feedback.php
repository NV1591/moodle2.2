<?php $this->cache['en']['block_feedback'] = array (
  'pluginname' => 'Feedback',
  'feedback' => 'Feedback',
  'missing_feedback_module' => 'This blocks relies on the Feedback activity module, but that module is not present!',
);