<?php $this->cache['en']['core_plagiarism'] = array (
  'availableplugins' => 'Available plugins',
  'configplagiarismplugins' => 'Please choose the plagiarism plugin you would like to configure',
  'enableplagiarism' => 'Enable plagiarism plugins',
  'configenableplagiarism' => 'This will allow administrators to configure plagiarism plugins (if installed)',
  'manageplagiarism' => 'Manage plagiarism plugins',
  'nopluginsinstalled' => 'No plagiarism plugins are installed.',
  'plagiarism' => 'Plagiarism prevention',
  'plagiarismsettings' => 'Plagiarism settings',
);