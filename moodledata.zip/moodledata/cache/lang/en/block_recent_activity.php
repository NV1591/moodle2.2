<?php $this->cache['en']['block_recent_activity'] = array (
  'pluginname' => 'Recent activity',
);