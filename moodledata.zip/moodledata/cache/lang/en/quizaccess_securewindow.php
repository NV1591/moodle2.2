<?php $this->cache['en']['quizaccess_securewindow'] = array (
  'pluginname' => 'JavaScript security quiz access rule',
  'popupwithjavascriptsupport' => 'Full screen pop-up with some JavaScript security',
);