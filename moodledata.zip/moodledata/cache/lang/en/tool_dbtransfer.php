<?php $this->cache['en']['tool_dbtransfer'] = array (
  'dbexport' => 'Database transfer',
  'dbtransfer' => 'Database export',
  'exportdata' => 'Export data',
  'notargetconectexception' => 'Can not connect target database, sorry.',
  'pluginname' => 'Database transfer',
  'transferdata' => 'Transfer data',
  'transferdbintro' => 'This script will transfer the entire contents of this database to another database server.',
  'transferdbtoserver' => 'Transfer this Moodle database to another server',
  'transferringdbto' => 'Transferring this database to {$a->dbtype} database {$a->dbname} on {$a->dbhost}',
);