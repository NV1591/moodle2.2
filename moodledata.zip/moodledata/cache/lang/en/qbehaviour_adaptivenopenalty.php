<?php $this->cache['en']['qbehaviour_adaptivenopenalty'] = array (
  'pluginname' => 'Adaptive mode (no penalties)',
);