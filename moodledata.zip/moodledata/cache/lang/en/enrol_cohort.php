<?php $this->cache['en']['enrol_cohort'] = array (
  'ajaxmore' => 'More...',
  'cohortsearch' => 'Search',
  'cohort:config' => 'Configure cohort instances',
  'pluginname' => 'Cohort sync',
  'pluginname_desc' => 'Cohort enrolment plugin synchronises cohort members with course participants.',
);