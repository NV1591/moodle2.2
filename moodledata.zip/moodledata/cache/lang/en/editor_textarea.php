<?php $this->cache['en']['editor_textarea'] = array (
  'pluginname' => 'Plain text area',
);