<?php $this->cache['en']['block_blog_tags'] = array (
  'pluginname' => 'Blog tags',
);