<?php $this->cache['en']['filter_multilang'] = array (
  'filtername' => 'Multi-Language Content',
);